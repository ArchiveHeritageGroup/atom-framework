# AtoM AHG Docker

## Installation Modes

| Mode | Profile | Description | Command |
|------|---------|-------------|---------|
| **Complete** | default | AtoM 2.10 + Framework + Extensions | `docker compose up -d` |
| **AtoM Only** | atom | Base AtoM 2.10 (no extensions) | `docker compose --profile atom up -d` |

## Quick Start
```bash
# 1. Copy environment file
cp .env.example .env

# 2. Edit settings
nano .env

# 3. Start services (Complete mode - default)
docker compose up -d

# Or start base AtoM only
docker compose --profile atom up -d

# 4. View logs
docker compose logs -f atom

# 5. Access AtoM
open http://localhost:8000
```

## Commands
```bash
# Stop services
docker compose down

# Stop and remove volumes (WARNING: deletes data)
docker compose down -v

# Rebuild images
docker compose build --no-cache

# Shell access
docker compose exec atom sh

# Run AtoM command
docker compose exec atom php symfony help
```

## Default Credentials

- **AtoM Admin**: demo@example.com / demo
- **MySQL Root**: root / atomroot
- **MySQL User**: atom / atompass

## Volumes

| Volume | Purpose |
|--------|---------|
| mysql_data | Database storage |
| es_data | Elasticsearch indices |
| atom_uploads | Uploaded files |
| atom_downloads | Generated exports |
