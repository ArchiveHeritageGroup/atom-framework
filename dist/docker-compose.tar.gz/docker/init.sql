-- AtoM Database Initialization
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
