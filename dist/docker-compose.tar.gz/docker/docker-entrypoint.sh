#!/bin/sh
set -e

ATOM_ROOT="/usr/share/nginx/atom"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║             AtoM AHG Docker Startup                          ║"
echo "╚══════════════════════════════════════════════════════════════╝"

# Wait for MySQL
echo "Waiting for MySQL..."
until mysql -h "${MYSQL_HOST:-mysql}" -u "${MYSQL_USER:-atom}" -p"${MYSQL_PASSWORD:-atompass}" -e "SELECT 1" > /dev/null 2>&1; do
    sleep 2
done
echo "✓ MySQL is ready"

# Wait for Elasticsearch
echo "Waiting for Elasticsearch..."
until curl -s "http://${ATOM_ES_HOST:-elasticsearch}:9200/_cluster/health" > /dev/null 2>&1; do
    sleep 2
done
echo "✓ Elasticsearch is ready"

# Create config.php if not exists
if [ ! -f "${ATOM_ROOT}/config/config.php" ]; then
    echo "Creating config.php..."
    cat > "${ATOM_ROOT}/config/config.php" << EOFCONFIG
<?php
return [
    'all' => [
        'propel' => [
            'class' => 'sfPropelDatabase',
            'param' => [
                'encoding' => 'utf8mb4',
                'persistent' => true,
                'pooling' => true,
                'dsn' => 'mysql:host=${MYSQL_HOST:-mysql};dbname=${MYSQL_DATABASE:-atom};charset=utf8mb4',
                'username' => '${MYSQL_USER:-atom}',
                'password' => '${MYSQL_PASSWORD:-atompass}',
            ],
        ],
    ],
];
EOFCONFIG
fi

# Initialize database if needed
if ! mysql -h "${MYSQL_HOST:-mysql}" -u "${MYSQL_USER:-atom}" -p"${MYSQL_PASSWORD:-atompass}" "${MYSQL_DATABASE:-atom}" -e "SELECT id FROM setting LIMIT 1" > /dev/null 2>&1; then
    echo "Initializing AtoM database..."
    cd "${ATOM_ROOT}"
    php symfony tools:install --demo --no-confirmation
    echo "✓ Database initialized"
fi

# Run AHG framework install if present
if [ -d "${ATOM_ROOT}/atom-framework" ] && [ -f "${ATOM_ROOT}/atom-framework/bin/install" ]; then
    echo "Running AHG Framework install..."
    cd "${ATOM_ROOT}/atom-framework"
    bash bin/install --auto 2>/dev/null || true
    echo "✓ AHG Framework configured"
fi

# Set permissions
chown -R www-data:www-data "${ATOM_ROOT}/cache" "${ATOM_ROOT}/log" "${ATOM_ROOT}/uploads" 2>/dev/null || true

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  AtoM is starting...                                         ║"
echo "║  URL: ${ATOM_SITE_BASE_URL:-http://localhost:8000}           ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

exec "$@"
