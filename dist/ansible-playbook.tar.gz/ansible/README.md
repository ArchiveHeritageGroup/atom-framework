# AtoM AHG Ansible Playbook

## Installation Modes

| Mode | Description | Command |
|------|-------------|---------|
| **complete** | Fresh AtoM 2.10 + Framework + Extensions | `ansible-playbook -i inventory.yml atom-ahg-install.yml` |
| **extensions** | Add extensions to existing AtoM | `ansible-playbook -i inventory.yml atom-ahg-install.yml -e "install_mode=extensions"` |
| **atom** | Base AtoM 2.10 only | `ansible-playbook -i inventory.yml atom-ahg-install.yml -e "install_mode=atom"` |

## Quick Start
```bash
# 1. Install Ansible
pip install ansible

# 2. Edit inventory with your servers
nano inventory.yml

# 3. (Optional) Create vault for passwords
ansible-vault create group_vars/vault.yml

# 4. Run installation
ansible-playbook -i inventory.yml atom-ahg-install.yml
```

## Per-Host Configuration

Create `host_vars/hostname.yml` for host-specific settings:
```yaml
---
install_mode: extensions
atom_path: /var/www/atom
mysql_atom_password: "secretpassword"
```

## Requirements

- Ansible 2.10+
- Target: Ubuntu 22.04 LTS
- SSH access with sudo privileges
