<?php

/**
 * Authority Record Report Action - Migrated to Framework v2.
 *
 * BEFORE: Used Propel Criteria directly (200+ lines)
 * AFTER: Uses AuthorityRecordReportService (30 lines)
 *
 * @author Johan Pieterse <pieterse.johan3@gmail.com>
 */
class reportsReportAuthorityRecordAction extends sfAction
{
    public function execute($request)
    {
        // Authorization check
        if (!$this->hasReportAccess()) {
            QubitAcl::forwardUnauthorized();
        }

        // Create form
        $this->form = $this->createReportForm();

        // Bind request parameters
        $this->form->bind(
            $request->getRequestParameters() + 
            $request->getGetParameters() + 
            $this->getDefaultParameters()
        );

        // Execute search if form is valid
        if ($this->form->isValid()) {
            $this->executeSearch();
        }
    }

    /**
     * Execute the report search using the service.
     */
    private function executeSearch(): void
    {
        // Create filter from form
        $filter = \AtomExtensions\Reports\ReportFilter::fromForm($this->form);

        // Get service (Laravel Query Builder)
        $service = $this->getReportService();

        // Execute search
        $this->results = $service->search($filter);

        // Get statistics
        $this->statistics = $service->getStatistics();
    }

    /**
     * Get the report service with dependencies.
     */
    private function getReportService(): \AtomExtensions\Reports\AuthorityRecordReportService
    {
        $repository = new \AtomExtensions\Repositories\ActorRepository();
        $logger = $this->getLogger();

        return new \AtomExtensions\Reports\AuthorityRecordReportService(
            $repository,
            $logger
        );
    }

    /**
     * Create the report form.
     */
    private function createReportForm(): sfForm
    {
        $form = new sfForm([], [], false);
        $form->getValidatorSchema()->setOption('allow_extra_fields', true);

        // Use FormFieldFactory to add fields
        \AtomExtensions\Forms\FormFieldFactory::addDateFields($form);
        \AtomExtensions\Forms\FormFieldFactory::addControlFields($form);

        // Add entity type selector
        $this->addEntityTypeField($form);

        return $form;
    }

    /**
     * Add entity type dropdown (Person, Corporate body, Family).
     */
    private function addEntityTypeField(sfForm $form): void
    {
        $choices = [null => 'All types'];

        // Get entity types from database
        foreach (QubitTerm::getByParentId(QubitTerm::ACTOR_ENTITY_TYPE_ID) as $term) {
            $choices[$term->id] = $term->__toString();
        }

        $form->setValidator('entityType', new sfValidatorString(['required' => false]));
        $form->setWidget('entityType', new sfWidgetFormSelect(['choices' => $choices]));
    }

    /**
     * Get default form parameters.
     */
    private function getDefaultParameters(): array
    {
        return [
            'className' => 'QubitActor',
            'dateStart' => date('d/m/Y', strtotime('-1 month')),
            'dateEnd' => date('d/m/Y'),
            'dateOf' => 'CREATED_AT',
            'limit' => '20',
            'sort' => 'updatedDown',
            'page' => '1',
        ];
    }

    /**
     * Check if user has report access.
     */
    private function hasReportAccess(): bool
    {
        return $this->context->user->isAdministrator()
            || $this->context->user->isSuperUser()
            || $this->context->user->isAuditUser();
    }

    /**
     * Get logger instance.
     */
    private function getLogger(): \Psr\Log\LoggerInterface
    {
        static $logger = null;

        if ($logger === null) {
            $logger = new \Monolog\Logger('reports');
            $logger->pushHandler(
                new \Monolog\Handler\StreamHandler(
                    sfConfig::get('sf_log_dir', '/var/log/atom') . '/atom-reports.log',
                    \Monolog\Logger::DEBUG
                )
            );
        }

        return $logger;
    }
}
